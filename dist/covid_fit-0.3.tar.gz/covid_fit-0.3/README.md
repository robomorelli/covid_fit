This package allow:
1)Dowload more recent csv file fromm protezione civile repository 
2)Make same simple fit analysis to study the trend in all regioni and province italiane
