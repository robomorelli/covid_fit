import setuptools

setuptools.setup(name='covid_fit',
      version='0.3',
      description='Fit utilities to analyze covid data',
      author='Roberto Morelli',
      author_email='roberto.morelli7@unibo.it',
      url='https://github.com/robomorelli/covid_fit',
      packages=setuptools.find_packages(),
     )
