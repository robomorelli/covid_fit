#!/usr/local/bin/python3

from .funcs import lin_func, lin_func_fit, exp_func, exp_func_fit\
                   , logistic_func, logistic_func_fit, logistic_der_func, logistic_der_func_fit\
                   , gompertz_func, gompertz_func_fit, gompertz_der_func, gompertz_der_func_fit\
                   , logistic_gen_func, logistic_gen_func_fit, logistic_gen_der_func,logistic_gen_der_func_fit
